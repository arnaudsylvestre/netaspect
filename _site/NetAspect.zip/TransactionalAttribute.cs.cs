using System;
using System.Reflection;

namespace NetAspect.Aspects
{
	public class TransactionalAttribute : Attribute
{
	private static NHibernate.ISession session;

	public bool NetAspectAttribute = true;

	private NHibernate.ITransaction transaction;

	public static void SetSession (NHibernate.ISession newSession)
	{
		session = newSession;
	}

	public void AfterMethod ()
	{
		transaction.Commit ();
	}

	public void BeforeMethod ()
	{
		transaction = session.BeginTransaction ();
	}

	public void OnExceptionMethod ()
	{
		transaction.Rollback ();
	}
}

}